#define LEDS 6
#define BTN 7

const int leds[] = {1,2,3,4,5,6};

volatile bool tick = false;
uint8_t seconds = 0;

int step = 0;
bool direction = true;

int mode = 0;

bool lastBtn = HIGH;

void setup() {

  for(int i=0;i<LEDS;i++){
    pinMode(leds[i], OUTPUT);
  }

  pinMode(BTN, INPUT_PULLUP);

  // Timer1 CTC
  cli();
  TCCR1A = 0;
  TCCR1B = 0;

  OCR1A = 15624;

  TCCR1B |= (1 << WGM12);
  TCCR1B |= (1 << CS12) | (1 << CS10);

  TIMSK1 |= (1 << OCIE1A);
  sei();
}

void loop() {

  // ⏱ timer tick
  if(tick){
    tick = false;
    seconds++;
  }

  // 🔘 button (edge detection)
  bool btnNow = digitalRead(BTN);

  if(lastBtn == HIGH && btnNow == LOW){
    mode++;
    if(mode > 2) mode = 0;

    step = 0;
    direction = true;
  }

  lastBtn = btnNow;

  // ⏱ har 1 sekundda step yangilanadi
  if(seconds >= 1){
    seconds = 0;

    // MODE1: oddiy ketma-ket
    if(mode == 0){
      step++;
      if(step >= LEDS){
        step = 0;
      }
    }

    // MODE2: ping-pong
    else if(mode == 1){
      if(direction){
        step++;
        if(step == LEDS-1){
          direction = false;
        }
      }else{
        step--;
        if(step == 0){
          direction = true;
        }
      }
    }

    // MODE3: piramida
    else if(mode == 2){
      if(direction){
        step++;
        if(step == LEDS){
          direction = false;
        }
      }else{
        step--;
        if(step == 0){
          direction = true;
        }
      }
    }
  }

  // 💡 LED chiqishi

  for(int i=0;i<LEDS;i++){

    // MODE1 & MODE2 → bitta LED
    if(mode == 0 || mode == 1){
      digitalWrite(leds[i], i == step ? HIGH : LOW);
    }

    // MODE3 → piramida
    else if(mode == 2){
      digitalWrite(leds[i], i < step ? HIGH : LOW);
    }

  }

}

// ⏱ interrupt
ISR(TIMER1_COMPA_vect){
  tick = true;
}